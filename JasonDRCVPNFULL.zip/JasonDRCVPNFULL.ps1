Add-vpnconnection -Name DRCVPNFULL -ServerAddress 111.207.128.194 -TunnelType l2tp -AuthenticationMethod pap -RememberCredential -l2tpPsk greatwall

